HT = nil

TriggerEvent('HT_base:getBaseObjects', function(obj) HT = obj end)

local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","ul-license")

function AddLicense(target, type, cb)
	local user_id = vRP.getUserId({target})

	if user_id then
		MySQL.Async.execute('INSERT INTO user_licenses (type, user_id) VALUES (@type, @user_id)', {
			['@type']  = type,
			['@user_id'] = user_id
		}, function(rowsChanged)
			if cb then
				cb()
			end
		end)
	else
		if cb then
			cb()
		end
	end
end

function RemoveLicense(target, type, cb)
	local user_id = vRP.getUserId({target})

	if user_id then
		MySQL.Async.execute('DELETE FROM user_licenses WHERE type = @type AND user_id = @user_id', {
			['@type'] = type,
			['@user_id'] = user_id
		}, function(rowsChanged)
			if cb then
				cb()
			end
		end)
	else
		if cb then
			cb()
		end
	end
end

function GetLicense(type, cb)
	MySQL.Async.fetchAll('SELECT label FROM licenses WHERE type = @type', {
		['@type'] = type
	}, function(result)
		local data = {
			type  = type,
			label = result[1].label
		}

		cb(data)
	end)
end

function GetLicenses(target, cb)
	local user_id = vRP.getUserId({target})

	MySQL.Async.fetchAll('SELECT type FROM user_licenses WHERE user_id = @user_id', {
		['@user_id'] = user_id
	}, function(result)
		local licenses, asyncTasks = {}, {}

		for i=1, #result, 1 do
			local scope = function(type)
				table.insert(asyncTasks, function(cb)
					MySQL.Async.fetchAll('SELECT label FROM user_licenses WHERE type = @type', {
						['@type'] = type
					}, function(result2)
						table.insert(licenses, {
							type  = type,
							label = result2[1].label
						})

						cb()
					end)
				end)
			end

			scope(result[i].type)
		end

		Async.parallel(asyncTasks, function(results)
			cb(licenses)
		end)
	end)
end

function CheckLicense(target, type, cb)
	local user_id = vRP.getUserId({target})

	if user_id then
		MySQL.Async.fetchAll('SELECT COUNT(*) as count FROM user_licenses WHERE type = @type AND user_id = @user_id', {
			['@type'] = type,
			['@user_id'] = user_id
		}, function(result)
			if tonumber(result[1].count) > 0 then
				cb(true)
			else
				cb(false)
			end
		end)
	else
		cb(false)
	end
end

function GetLicensesList(cb)
	MySQL.Async.fetchAll('SELECT type, label FROM licenses', {
		['@type'] = type
	}, function(result)
		local licenses = {}

		for i=1, #result, 1 do
			table.insert(licenses, {
				type  = result[i].type,
				label = result[i].label
			})
		end

		cb(licenses)
	end)
end

RegisterNetEvent('ul-license:addLicense')
AddEventHandler('ul-license:addLicense', function(target, type, cb)
	AddLicense(target, type, cb)
end)

RegisterNetEvent('ul-license:removeLicense')
AddEventHandler('ul-license:removeLicense', function(target, type, cb)
	RemoveLicense(target, type, cb)
end)

AddEventHandler('ul-license:getLicense', function(type, cb)
	GetLicense(type, cb)
end)

AddEventHandler('ul-license:getLicenses', function(target, cb)
	GetLicenses(target, cb)
end)

AddEventHandler('ul-license:checkLicense', function(target, type, cb)
	CheckLicense(target, type, cb)
end)

AddEventHandler('ul-license:getLicensesList', function(cb)
	GetLicensesList(cb)
end)

WILD.RegisterServerCallback('ul-license:getLicense', function(source, cb, type)
	GetLicense(type, cb)
end)

WILD.RegisterServerCallback('ul-license:getLicenses', function(source, cb, target)
	GetLicenses(target, cb)
end)

WILD.RegisterServerCallback('ul-license:checkLicense', function(source, cb, target, type)
	CheckLicense(target, type, cb)
end)

WILD.RegisterServerCallback('ul-license:getLicensesList', function(source, cb)
	GetLicensesList(cb)
end)