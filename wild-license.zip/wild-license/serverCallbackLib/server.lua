WILD = {}
WILD.ServerCallbacks = {}

RegisterServerEvent('WILD:triggerServerCallback')
AddEventHandler('WILD:triggerServerCallback', function(name, requestId, ...)
	local _source = source

	WILD.TriggerServerCallback(name, requestID, _source, function(...)
		TriggerClientEvent('WILD:serverCallback', _source, requestId, ...)
	end, ...)
end)

WILD.RegisterServerCallback = function(name, cb)
	WILD.ServerCallbacks[name] = cb
end

WILD.TriggerServerCallback = function(name, requestId, source, cb, ...)
	if WILD.ServerCallbacks[name] ~= nil then
		WILD.ServerCallbacks[name](source, cb, ...)
	else
		print('WILD.TriggerServerCallback => [' .. name .. '] does not exist')
	end
end