resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

dependency 'vrp'

description 'UL License'

version '1.0.1'

server_scripts {
	'@vrp/lib/utils.lua',
	'@async/async.lua',
	'serverCallbackLib/server.lua',
	'@mysql-async/lib/MySQL.lua',
	'server/main.lua'
}


